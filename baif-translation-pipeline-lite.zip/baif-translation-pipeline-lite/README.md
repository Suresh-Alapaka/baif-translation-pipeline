# BAIF Offline Indic Translation Pipeline — LITE Version

Same pipeline, same outputs (translated text, dubbed audio, SRT/VTT
subtitles, captioned video) — but using the smallest viable model at
every stage, for much faster processing on machines without a GPU.

| Component | Lite model | Approx size |
|---|---|---|
| Speech-to-Text | Whisper SMALL (faster-whisper, int8) | ~480 MB |
| Translation | IndicTrans2 DISTILLED 200M / 320M | ~1-2 GB each |
| Text-to-Speech | Facebook MMS-TTS (VITS) | ~150 MB per language |

Total download: under 3 GB (vs ~18 GB for the full version).
A 1-minute video should process in roughly 1-3 minutes on CPU.

---

## Verified Setup Steps (Windows)

### Step 1 — Install ffmpeg
```
winget install ffmpeg
```
Close and reopen Command Prompt. Verify: `ffmpeg -version`

### Step 2 — Install Microsoft C++ Build Tools
Needed to build IndicTransToolkit.
https://visualstudio.microsoft.com/visual-cpp-build-tools/
Select "Desktop development with C++", install, restart terminal.

### Step 3 — Create virtual environment
```
cd C:\Users\<your-username>
python -m venv whisper-env
whisper-env\Scripts\activate
```

### Step 4 — Install packages
```
pip install --upgrade pip
pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu121
pip install torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cu121
pip install faster-whisper
pip install transformers==4.46.1 sentencepiece
pip install IndicTransToolkit
pip install scipy soundfile pydub flask
pip install "huggingface-hub>=0.23.2,<1.0"
```

Note: no Parler-TTS install needed in the lite version — MMS-TTS
uses transformers directly.

### Step 5 — Authenticate with Hugging Face
```
hf auth login
```
Paste your token (from https://huggingface.co/settings/tokens).

Visit and accept access on these gated pages (MMS-TTS is NOT gated,
only IndicTrans2 distilled models are):
- https://huggingface.co/ai4bharat/indictrans2-en-indic-dist-200M
- https://huggingface.co/ai4bharat/indictrans2-indic-en-dist-200M
- https://huggingface.co/ai4bharat/indictrans2-indic-indic-dist-320M

### Step 6 — Download models (one time)
```
python scripts/download_models.py
```

### Step 7 — Test (optional but recommended)
```
python scripts/test_components.py path\to\audio.mp3
```

### Step 8 — Run the app
```
python app_flask.py
```
Open browser at: http://localhost:5000

---

## Using the App

Same as the full version:
1. Upload video/audio/text
2. Select target language
3. Click Process & Translate
4. Watch live log, then play/download the result

Output filenames: `hindi_filename.mp4`, `marathi_filename.srt`, etc.

---

## Project Structure
```
baif-translation-pipeline-lite/
├── app_flask.py
├── requirements.txt
├── README.md
├── .gitignore
├── scripts/
│   ├── download_models.py
│   └── test_components.py
├── output/
└── uploads/
```

---

## Common Errors

whisper module not found
-> Use faster-whisper, not openai-whisper.

403 Forbidden on IndicTrans2 distilled models
-> Visit the 3 model pages above and click "Agree and access repository".

MMS-TTS download fails
-> These are NOT gated, no login needed for them specifically. If it still
   fails, check your internet connection.

Microsoft Visual C++ 14.0 required
-> Install C++ Build Tools.

torchaudio mismatch
-> pip install torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cu121
